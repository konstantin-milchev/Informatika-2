package Homework6;

public class Client {
	public static void main(String[] args) {
		
		//Erstelle Ordner und Files
		Directory Hauptordner= new Directory("Hauptordner");
		Directory Unterordner1= new Directory("1.Unter");
		Directory Unterordner2= new Directory("2.Unter");
		
		File file1 = new File("1.File");
		File file2 = new File("2.File");
		File file3 = new File("3.File");
		File file4 = new File("4.File");
		File file5 = new File("5.File");
		
		//Ordne sie jeweils ein in das System
		
		//Alles in den Hauptordner
		Hauptordner.addFileSystemElement(Unterordner1);
		
		Hauptordner.addFileSystemElement(file1);
		Hauptordner.addFileSystemElement(file2);
		
		//in den 1.Unterordner Einsortieren
		Unterordner1.addFileSystemElement(Unterordner2);
		
		Unterordner1.addFileSystemElement(file3);
		Unterordner1.addFileSystemElement(file4);
		
		//in den 2.Unterordner Einsortieren
		Unterordner2.addFileSystemElement(file5);
		
		
		//Drucken wir mal was so drin ist
		Hauptordner.printInformation();
		
		for (FileSystemElement s : Hauptordner.List) {
			s.printInformation();
		}
		//Im Unterordner 1 ist:
		System.out.println("Im "+Unterordner1.DirectoryName+ "ist: ");
		for (FileSystemElement s : Unterordner1.List) {
			s.printInformation();
		}
		
		//Im Unterordner 2 ist:
				System.out.println("Im "+Unterordner2.DirectoryName+ "ist: ");
				for (FileSystemElement s : Unterordner2.List) {
					s.printInformation();
				}
	}
}
