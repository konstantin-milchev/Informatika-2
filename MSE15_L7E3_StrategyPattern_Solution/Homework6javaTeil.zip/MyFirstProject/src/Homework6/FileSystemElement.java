package Homework6;

public class FileSystemElement {
	//Wird je nachdem ob File oder Directory implementiert
	//M�sste dann FileSystemElement nicht eine abstract class sein ? => In Diagramm nicht kursiv ?
	public void printInformation () {
	}

}
