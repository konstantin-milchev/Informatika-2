package Homework6;

public class File extends FileSystemElement {
	private String FileName;

	//Constructor
	public File(String FileName) {
		this.FileName=FileName;
	}
	@Override
	public void printInformation () {
		System.out.println("File Name ist:"+ FileName);
	}

}
