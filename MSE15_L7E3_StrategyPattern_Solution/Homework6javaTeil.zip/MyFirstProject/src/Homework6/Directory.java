package Homework6;

import java.util.ArrayList;

public class Directory extends FileSystemElement{
	public String DirectoryName;
	//Constructor
	public Directory(String DirectoryName) {
		this.DirectoryName=DirectoryName;
	}
	@Override
	public void printInformation() {
		System.out.println("Directory Name ist:"+DirectoryName);
	}
	
	public ArrayList<FileSystemElement> List= new ArrayList<FileSystemElement>();
	
	public void addFileSystemElement(FileSystemElement Element){
		List.add(Element);
	}
	
	public void removeFileSystemElement(FileSystemElement Element){
		List.remove(Element);
	}

}