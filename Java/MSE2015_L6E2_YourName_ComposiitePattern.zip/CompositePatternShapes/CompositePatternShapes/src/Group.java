import java.util.ArrayList;


public class Group extends Shape{
	
	

	public void addGraphic(Shape graphic) {
		// TO DO
	}

	public void removeGraphic(Shape graphic) {
		//TO DO
	}

	public void draw(){
		System.out.println("Drawing elements of group");
		// TO DO
		System.out.println("Finished drawing elements of group");
	}
}
