
public class Oval extends Shape {

	@Override
	public void draw() {
		System.out.println("I draw Oval.");
		
	}

}
