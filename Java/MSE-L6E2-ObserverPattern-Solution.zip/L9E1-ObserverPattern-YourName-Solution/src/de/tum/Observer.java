package de.tum;

public abstract class Observer {

	Subject observedSubject;

	public abstract void update();
}
